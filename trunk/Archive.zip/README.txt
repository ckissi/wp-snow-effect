=== WP Snow Effect ===
Contributors: WPManiax 
Donate link: http://www.wpmaniax.com/ 
Tags: snow effect, christmas, christmas snow, falling snow, holiday, holiday snow, jquery snow, jsnow, let it snow, snow, snow balls, snow effect, snow effects, Snow Flakes, snowball, snowflake, snowing, super snow, supersnow, wp snow
Requires at least: 3.6
Tested up to: 5.5.3
Requires PHP: 5.6
Stable tag: 1.1.15
License:GPL2
 
Add nice looking animation effect of falling snow to your Wordpress site and enjoy winter and Christmas.


== Description == 

Add nice looking animation effect of falling snow to your Wordpress site and enjoy winter and Christmas.

Simulate snow storm by adjusting the snow falling speed. 

This snow falling WP plugin uses jSnow JQuery plugin (2kb only) and no images.


*   [Upgrade to the WP Snow Effect Pro Version Now! &raquo;](http://www.wpmaniax.com/wp-snow-effect-pro/?utm_source=wordpress.org&utm_medium=link&utm_campaign=wp-snow-effect-pro-from-wordpress.org "WP Snow Effect Pro Version")
*   For more information take a look at the [video preview](http://www.wpmaniax.com/wp-snow-effect-pro/?utm_source=wordpress.org&utm_medium=link&utm_campaign=wp-snow-effect-video-from-wordpress.org "WP Snow Effect Video Preview")


> <strong>WP Snow Effect PRO</strong><br>
> There is a PRO version of WP Snow Effect available with following features:
>
> * <strong>Ability to show Snow Effect on specific pages</strong>
> * Easy to install and configure
> * 40 flake types to choose from including Snowman.
> * Define number of snowflakes
> * Define maximal and minimal size of snowflake
> * Define maximal and minimal size of fall speed
> * Define flake color
> * Enable/Disable fade away effect
> * Configurable Z-Index to avoid theme conflicts
> * Configure where to show (posts, pages, home, archives)
> * One year of free upgrades and support
>
> **[LEARN MORE ABOUT WP SNOW EFFECT PRO](http://www.wpmaniax.com/wp-snow-effect-pro)**


== Installation == 

1. Drop the 'wp-snow-effect' folder into your 'wp-content/plugins' folder
 
2. Go to your Administration: Plugins page and activate the "WP snow effect" plugin

3. Go to Settings / WP Snow Effect to configure the plugin

== Screenshots ==

1. Animated screenshot of home page

2. Static screenshot of home page

3. Settings page

== Changelog ==

= 1.1.15 =
* fixed jQuery 3.1 incompatibility in admin file

= 1.1.14 =
* jQuery 3.1 compatibility improvements

= 1.1.13 =
* Display on mobile is enabled by default 

= 1.1.12 =
* fixed jQuery 3.1 incompatibility

= 1.1.11 =
* tested compatibility for WordPress 5.5.3

= 1.1.10 =
* tested compatibility for WordPress 5.3.1

= 1.1.9 =
* fixed Screen_icon deprecated function issue

= 1.1.8 =
* fixed Popup menu lost focus issue

= 1.1.7 =
* fixed PHP array issue

= 1.1.6 =
* fixed infinity scroll issue

= 1.1.5 =
* changed snow color and vertical snow size default values

= 1.1.4 =
* box with review request added

= 1.1.3 =
* minor changes in settings

= 1.1.2 =
* minor compatibility changes

= 1.1.1 =
* minor changes in admin section

= 1.1.0 =
* added capability to change snow flake type
* added Z-Index
* added mobile device support

= 1.0.0 =
* completely rewritten code based on WP plugin boilerplate
* added settings section

= 0.8.2 =
* fixed $.browser.msie JS issue 

= 0.8.1 =
* minor changes 

= 0.8.0 =
* initial release 

== Upgrade Notice ==

= 1.1.15 =
* fixed jQuery 3.1 incompatibility in admin file

= 1.1.14 =
* jQuery 3.1 compatibility improvements

= 1.1.13 =
* Display on mobile is enabled by default 

= 1.1.12 =
* fixed jQuery 3.1 incompatibility

= 1.1.11 =
* tested compatibility for WordPress 5.5.3

= 1.1.10 =
* tested for WordPress 5.3.1

= 1.1.9 =
* fixed Screen_icon deprecated function issue

= 1.1.8 =
* fixed Popup menu lost focus issue

= 1.1.7 =
* fixed PHP array issue

= 1.1.6 =
* fixed infinity scroll issue

= 1.1.5 =
* changed snow color and vertical snow size default values

= 1.1.4 =
* box with review request added

= 1.1.3 =
* minor changes in settings

= 1.1.2 =
* minor compatibility changes

= 1.1.1 =
* minor changes in admin section

= 1.1.0 =
* added capability to change snow flake type
* added Z-Index
* added mobile device support

= 1.0.0 =
* completely rewritten code based on WP plugin boilerplate
* added settings section

= 0.8.2 =
* fixed $.browser.msie JS issue 

= 0.8.1 =
* minor changes

= 0.8.0 =
* initial release

== Frequently Asked Questions ==
No questions
 
== Feedback == 
For more information and comments please visit the [WP Snow Effect WP plugin](http://www.wpmaniax.com/wp-snow-effect/?utm_source=wordpress.org&utm_medium=link&utm_campaign=wp-snow-effect-feedback-from-wordpress.org) home